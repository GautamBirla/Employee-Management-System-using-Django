from django.urls import path
from . import views
from .views import delete_employee

urlpatterns = [
    path('', views.home, name='home'),
    path('view_all_employees/', views.view_all_employees, name='view_all_employees'),
    path('create_employee/', views.create_employee, name='create_employee'),
    path('resign_employee/<int:pk>/', views.resign_employee, name='resign_employee'),
    path('edit_employee/<int:pk>/', views.edit_employee, name='edit_employee'),
    path('edit_employee/<int:employee_id>/', views.edit_employee, name='edit_employee'),
    path('delete_employee/<int:employee_id>/', views.delete_employee, name='delete_employee'),
    path('delete_employee/<int:pk>/', views.delete_employee, name='delete_employee'),
    path('delete/<int:pk>/', delete_employee, name='delete_employee'),
]