from django.shortcuts import render, redirect, get_object_or_404
from .models import Employee
from .forms import EmployeeForm
import datetime
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from .models import Employee

def home(request):
    return render(request, 'home.html')

def view_all_employees(request):
    employees = Employee.objects.all()
    return render(request, 'view_all_employees.html', {'employees': employees})

def create_employee(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_all_employees')
    else:
        form = EmployeeForm()
    return render(request, 'create_employee.html', {'form': form})

def resign_employee(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    employee.status = 'Resigned'
    employee.resign_date = datetime.date.today()
    employee.save()
    return redirect(reverse('view_all_employees'))

def edit_employee(request, pk):
    employee = Employee.objects.get(employee_id=pk)
    if request.method == 'POST':
        form = EmployeeForm(request.POST, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('view_all_employees')
    else:
        form = EmployeeForm(instance=employee)
    return render(request, 'edit_employee.html', {'form': form})

def delete_employee(request, pk):
    print("Arguments:", request, pk)
    Employee.objects.filter(pk=pk).delete()
    return redirect('view_all_employees')